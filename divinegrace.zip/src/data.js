export const products = [
  {
    name: 'Fresh Fruits',
    group: 'Fresh produce',
    mark: '01',
    art: 'fruit',
    note: 'Fruit selections for import and export enquiries.',
  },
  {
    name: 'Vegetables',
    group: 'Fresh produce',
    mark: '02',
    art: 'vegetable',
    note: 'Vegetable selections for import and export enquiries.',
  },
  {
    name: 'Basmati Rice 1121',
    group: 'Food grains',
    mark: '03',
    art: 'grain',
    note: 'The rice variety named in the company profile.',
  },
  {
    name: 'Onions',
    detail: 'Red · White · Pink',
    group: 'Fresh produce',
    mark: '04',
    art: 'onion',
    note: 'Red, white and pink onions, as listed in the profile.',
  },
  {
    name: 'Spices',
    group: 'Food products',
    mark: '05',
    art: 'spice',
    note: 'Spices for import and export enquiries.',
  },
  {
    name: 'Pharmaceuticals',
    group: 'Medical items',
    mark: '06',
    art: 'medical',
    note: 'Pharmaceutical items listed in the company profile.',
  },
  {
    name: 'Personal Health Products',
    group: 'Medical items',
    mark: '07',
    art: 'wellness',
    note: 'Personal health products listed in the company profile.',
  },
];

export const values = [
  {
    number: '01',
    title: 'Trust',
    text: 'Reliable relationships and clear communication at every step.',
    icon: 'globe',
  },
  {
    number: '02',
    title: 'Quality',
    text: 'A considered approach to quality checks and product standards.',
    icon: 'spark',
  },
  {
    number: '03',
    title: 'Grace & integrity',
    text: 'Ethical, transparent conduct built around long-term partnership.',
    icon: 'seal',
  },
];

export const contact = {
  displayPhone: '8454813667',
  internationalPhone: '+918454813667',
  whatsappUrl:
    'https://wa.me/918454813667?text=Hello%20Divine%20Grace%2C%20I%27d%20like%20to%20discuss%20an%20import%20or%20export%20enquiry.',
  email: 'edwinfarel1966@gmail.com',
};
